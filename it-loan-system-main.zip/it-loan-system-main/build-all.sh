#!/bin/bash

echo "Building all services..."

# Build Eureka Server
echo "Building Eureka Server..."
mvn clean package -DskipTests

# Build Material Service
echo "Building Material Service..."
cd material-service
mvn clean package -DskipTests
cd ..

# Build Borrower Service
echo "Building Borrower Service..."
cd borrower-service
mvn clean package -DskipTests
cd ..

# Build Loan Service
echo "Building Loan Service..."
cd loan-service
mvn clean package -DskipTests
cd ..

# Build Auth Service
echo "Building Auth Service..."
cd auth-service
mvn clean package -DskipTests
cd ..

# Build API Gateway
echo "Building API Gateway..."
cd api-gateway
mvn clean package -DskipTests
cd ..

echo "All services built successfully!"

