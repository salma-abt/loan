package com.tp.material.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "materials")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Material {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message = "Le type est obligatoire")
	@Column(nullable = false)
	private String type; // PC, projecteur, imprimante, etc.
	
	@NotBlank(message = "La marque est obligatoire")
	@Column(nullable = false)
	private String marque;
	
	@NotBlank(message = "Le modèle est obligatoire")
	@Column(nullable = false)
	private String modele;
	
	@NotBlank(message = "Le numéro de série est obligatoire")
	@Column(nullable = false, unique = true)
	private String numeroSerie;
	
	@NotNull(message = "L'état est obligatoire")
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private MaterialState etat;
	
	@Column
	private String localisation;
	
	public enum MaterialState {
		DISPONIBLE,
		EMPRUNTE,
		EN_PANNE,
		EN_MAINTENANCE
	}
}

