package com.tp.material.controller;

import com.tp.material.dto.MaterialDTO;
import com.tp.material.model.Material.MaterialState;
import com.tp.material.service.MaterialService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/materials")
@RequiredArgsConstructor
public class MaterialController {
	
	private final MaterialService materialService;
	
	@GetMapping
	public ResponseEntity<List<MaterialDTO>> getAllMaterials() {
		return ResponseEntity.ok(materialService.getAllMaterials());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<MaterialDTO> getMaterialById(@PathVariable Long id) {
		return ResponseEntity.ok(materialService.getMaterialById(id));
	}
	
	@GetMapping("/available")
	public ResponseEntity<List<MaterialDTO>> getAvailableMaterials() {
		return ResponseEntity.ok(materialService.getAvailableMaterials());
	}
	
	@GetMapping("/state/{state}")
	public ResponseEntity<List<MaterialDTO>> getMaterialsByState(@PathVariable MaterialState state) {
		return ResponseEntity.ok(materialService.getMaterialsByState(state));
	}
	
	@PostMapping
	public ResponseEntity<MaterialDTO> createMaterial(@Valid @RequestBody MaterialDTO materialDTO) {
		return ResponseEntity.status(HttpStatus.CREATED)
				.body(materialService.createMaterial(materialDTO));
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<MaterialDTO> updateMaterial(
			@PathVariable Long id,
			@Valid @RequestBody MaterialDTO materialDTO) {
		return ResponseEntity.ok(materialService.updateMaterial(id, materialDTO));
	}
	
	@PatchMapping("/{id}/state")
	public ResponseEntity<MaterialDTO> updateMaterialState(
			@PathVariable Long id,
			@RequestParam("state") String stateStr) {
		if (stateStr == null || stateStr.trim().isEmpty()) {
			throw new RuntimeException("L'état ne peut pas être null ou vide");
		}
		// Convertir le String en enum MaterialState
		MaterialState state;
		try {
			state = MaterialState.valueOf(stateStr.toUpperCase().trim());
		} catch (IllegalArgumentException e) {
			throw new RuntimeException("État invalide: " + stateStr + ". États valides: DISPONIBLE, EMPRUNTE, EN_PANNE, EN_MAINTENANCE");
		}
		return ResponseEntity.ok(materialService.updateMaterialState(id, state));
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteMaterial(@PathVariable Long id) {
		materialService.deleteMaterial(id);
		return ResponseEntity.noContent().build();
	}
}

