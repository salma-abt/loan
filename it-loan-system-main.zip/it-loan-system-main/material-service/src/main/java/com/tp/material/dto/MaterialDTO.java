package com.tp.material.dto;

import com.tp.material.model.Material.MaterialState;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MaterialDTO {
	private Long id;
	private String type;
	private String marque;
	private String modele;
	private String numeroSerie;
	private MaterialState etat;
	private String localisation;
}

