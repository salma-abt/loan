package com.tp.material.service;

import com.tp.material.dto.MaterialDTO;
import com.tp.material.model.Material;
import com.tp.material.model.Material.MaterialState;
import com.tp.material.repository.MaterialRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class MaterialService {
	
	private final MaterialRepository materialRepository;
	
	@Transactional(readOnly = true)
	public List<MaterialDTO> getAllMaterials() {
		return materialRepository.findAll().stream()
				.map(this::toDTO)
				.collect(Collectors.toList());
	}
	
	@Transactional(readOnly = true)
	public MaterialDTO getMaterialById(Long id) {
		Material material = materialRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Matériel non trouvé avec l'ID: " + id));
		return toDTO(material);
	}
	
	public MaterialDTO createMaterial(MaterialDTO materialDTO) {
		if (materialDTO == null) {
			throw new RuntimeException("Le matériel ne peut pas être null");
		}
		if (materialDTO.getNumeroSerie() == null || materialDTO.getNumeroSerie().trim().isEmpty()) {
			throw new RuntimeException("Le numéro de série est obligatoire");
		}
		if (materialRepository.existsByNumeroSerie(materialDTO.getNumeroSerie())) {
			throw new RuntimeException("Un matériel avec ce numéro de série existe déjà");
		}
		Material material = toEntity(materialDTO);
		material = materialRepository.save(material);
		return toDTO(material);
	}
	
	public MaterialDTO updateMaterial(Long id, MaterialDTO materialDTO) {
		if (materialDTO == null) {
			throw new RuntimeException("Le matériel ne peut pas être null");
		}
		Material material = materialRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Matériel non trouvé avec l'ID: " + id));
		
		if (materialDTO.getNumeroSerie() != null && 
				!material.getNumeroSerie().equals(materialDTO.getNumeroSerie()) &&
				materialRepository.existsByNumeroSerie(materialDTO.getNumeroSerie())) {
			throw new RuntimeException("Un matériel avec ce numéro de série existe déjà");
		}
		
		material.setType(materialDTO.getType());
		material.setMarque(materialDTO.getMarque());
		material.setModele(materialDTO.getModele());
		material.setNumeroSerie(materialDTO.getNumeroSerie());
		material.setEtat(materialDTO.getEtat());
		material.setLocalisation(materialDTO.getLocalisation());
		
		material = materialRepository.save(material);
		return toDTO(material);
	}
	
	public void deleteMaterial(Long id) {
		if (!materialRepository.existsById(id)) {
			throw new RuntimeException("Matériel non trouvé avec l'ID: " + id);
		}
		materialRepository.deleteById(id);
	}
	
	@Transactional(readOnly = true)
	public List<MaterialDTO> getMaterialsByState(MaterialState state) {
		return materialRepository.findByEtat(state).stream()
				.map(this::toDTO)
				.collect(Collectors.toList());
	}
	
	@Transactional(readOnly = true)
	public List<MaterialDTO> getAvailableMaterials() {
		return getMaterialsByState(MaterialState.DISPONIBLE);
	}
	
	public MaterialDTO updateMaterialState(Long id, MaterialState newState) {
		Material material = materialRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Matériel non trouvé avec l'ID: " + id));
		material.setEtat(newState);
		material = materialRepository.save(material);
		return toDTO(material);
	}
	
	private MaterialDTO toDTO(Material material) {
		return new MaterialDTO(
				material.getId(),
				material.getType(),
				material.getMarque(),
				material.getModele(),
				material.getNumeroSerie(),
				material.getEtat(),
				material.getLocalisation()
		);
	}
	
	private Material toEntity(MaterialDTO dto) {
		Material material = new Material();
		material.setType(dto.getType());
		material.setMarque(dto.getMarque());
		material.setModele(dto.getModele());
		material.setNumeroSerie(dto.getNumeroSerie());
		material.setEtat(dto.getEtat() != null ? dto.getEtat() : MaterialState.DISPONIBLE);
		material.setLocalisation(dto.getLocalisation());
		return material;
	}
}

