package com.tp.material.repository;

import com.tp.material.model.Material;
import com.tp.material.model.Material.MaterialState;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MaterialRepository extends JpaRepository<Material, Long> {
	
	Optional<Material> findByNumeroSerie(String numeroSerie);
	
	List<Material> findByEtat(MaterialState etat);
	
	List<Material> findByType(String type);
	
	List<Material> findByLocalisation(String localisation);
	
	boolean existsByNumeroSerie(String numeroSerie);
}

