# Guide pour publier sur GitHub

## Étapes pour publier votre projet sur GitHub

### 1. Créer un nouveau dépôt sur GitHub

1. Allez sur [GitHub](https://github.com)
2. Cliquez sur le bouton **"+"** en haut à droite
3. Sélectionnez **"New repository"**
4. Remplissez les informations :
   - **Repository name** : `it-loan-system`
   - **Description** : `Système de gestion de prêts de matériel informatique - Architecture microservices avec Spring Boot`
   - **Visibilité** : Public ou Private (selon votre choix)
   - **NE PAS** cocher "Initialize this repository with a README" (nous avons déjà un README)
5. Cliquez sur **"Create repository"**

### 2. Initialiser Git dans votre projet local

Ouvrez un terminal dans le dossier du projet et exécutez :

```bash
# Initialiser Git (si pas déjà fait)
git init

# Ajouter tous les fichiers
git add .

# Faire le premier commit
git commit -m "Initial commit: Système de gestion de prêts IT avec architecture microservices"
```

### 3. Ajouter le dépôt distant GitHub

Remplacez `VOTRE-USERNAME` par votre nom d'utilisateur GitHub :

```bash
git remote add origin https://github.com/VOTRE-USERNAME/it-loan-system.git
```

### 4. Pousser le code vers GitHub

```bash
# Pousser vers la branche main
git branch -M main
git push -u origin main
```

### 5. Vérifier sur GitHub

Allez sur votre dépôt GitHub et vérifiez que tous les fichiers sont bien présents.

## Commandes Git utiles

```bash
# Voir le statut des fichiers
git status

# Ajouter des fichiers spécifiques
git add nom-du-fichier

# Voir l'historique des commits
git log

# Créer une nouvelle branche
git checkout -b nom-de-la-branche

# Pousser une branche vers GitHub
git push -u origin nom-de-la-branche
```

## Structure recommandée pour GitHub

Votre dépôt devrait contenir :
- ✅ README.md (documentation principale)
- ✅ .gitignore (fichiers à ignorer)
- ✅ .gitattributes (normalisation des fichiers)
- ✅ CONTRIBUTING.md (guide de contribution)
- ✅ docker-compose.yml
- ✅ Tous les services (material-service, borrower-service, etc.)
- ✅ Scripts de build (build-all.sh, build-all.bat)

## Badges à ajouter (optionnel)

Vous pouvez ajouter des badges dans votre README.md en remplaçant `VOTRE-USERNAME` :

```markdown
![GitHub stars](https://img.shields.io/github/stars/VOTRE-USERNAME/it-loan-system?style=social)
![GitHub forks](https://img.shields.io/github/forks/VOTRE-USERNAME/it-loan-system?style=social)
```

## Mise à jour du projet

Quand vous faites des modifications :

```bash
# Ajouter les changements
git add .

# Commit avec un message descriptif
git commit -m "Description des changements"

# Pousser vers GitHub
git push
```

## Tags et Releases (optionnel)

Pour créer une version :

```bash
# Créer un tag
git tag -a v1.0.0 -m "Version 1.0.0"

# Pousser le tag
git push origin v1.0.0
```

Ensuite, allez sur GitHub > Releases > "Create a new release" pour créer une release.

