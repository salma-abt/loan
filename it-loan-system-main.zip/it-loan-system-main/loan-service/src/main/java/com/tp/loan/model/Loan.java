package com.tp.loan.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "loans")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Loan {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull(message = "L'ID de l'emprunteur est obligatoire")
	@Column(nullable = false)
	private Long emprunteurId;
	
	@NotNull(message = "L'ID du matériel est obligatoire")
	@Column(nullable = false)
	private Long materielId;
	
	@NotNull(message = "La date de prêt est obligatoire")
	@Column(nullable = false)
	private LocalDate datePret;
	
	@NotNull(message = "La date de retour prévue est obligatoire")
	@Column(nullable = false)
	private LocalDate dateRetourPrevue;
	
	@Column
	private LocalDate dateRetour;
	
	@NotNull(message = "Le statut est obligatoire")
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private LoanStatus statut;
	
	@Column
	private Double penalite; // Pénalité en cas de retard
	
	public enum LoanStatus {
		EN_COURS,
		RETOURNE,
		EN_RETARD
	}
}

