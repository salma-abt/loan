package com.tp.loan.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@FeignClient(name = "material-service")
public interface MaterialClient {
	
	@GetMapping("/api/materials/{id}")
	Map<String, Object> getMaterialById(@PathVariable Long id);
	
	@PatchMapping("/api/materials/{id}/state")
	Map<String, Object> updateMaterialState(
			@PathVariable Long id,
			@RequestParam("state") String state);
}

