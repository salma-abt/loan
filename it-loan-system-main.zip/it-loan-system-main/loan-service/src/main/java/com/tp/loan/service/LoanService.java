package com.tp.loan.service;

import com.tp.loan.client.BorrowerClient;
import com.tp.loan.client.MaterialClient;
import com.tp.loan.dto.LoanDTO;
import com.tp.loan.model.Loan;
import com.tp.loan.model.Loan.LoanStatus;
import com.tp.loan.repository.LoanRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class LoanService {
	
	private final LoanRepository loanRepository;
	private final MaterialClient materialClient;
	private final BorrowerClient borrowerClient;
	
	// Règle métier : Un matériel ne peut être prêté que s'il est DISPONIBLE
	public LoanDTO createLoan(LoanDTO loanDTO) {
		if (loanDTO == null) {
			throw new RuntimeException("Le prêt ne peut pas être null");
		}
		if (loanDTO.getEmprunteurId() == null) {
			throw new RuntimeException("L'ID de l'emprunteur est obligatoire");
		}
		if (loanDTO.getMaterielId() == null) {
			throw new RuntimeException("L'ID du matériel est obligatoire");
		}
		if (loanDTO.getDateRetourPrevue() == null) {
			throw new RuntimeException("La date de retour prévue est obligatoire");
		}
		// Validation de la date de retour prévue
		if (loanDTO.getDateRetourPrevue().isBefore(LocalDate.now())) {
			throw new RuntimeException("La date de retour prévue ne peut pas être dans le passé");
		}
		
		// Vérifier que l'emprunteur existe
		try {
			borrowerClient.getBorrowerById(loanDTO.getEmprunteurId());
		} catch (Exception e) {
			throw new RuntimeException("Emprunteur non trouvé avec l'ID: " + loanDTO.getEmprunteurId(), e);
		}
		
		// Vérifier que le matériel existe et est disponible
		Map<String, Object> material;
		try {
			material = materialClient.getMaterialById(loanDTO.getMaterielId());
		} catch (Exception e) {
			throw new RuntimeException("Matériel non trouvé avec l'ID: " + loanDTO.getMaterielId(), e);
		}
		
		if (material == null) {
			throw new RuntimeException("Matériel non trouvé avec l'ID: " + loanDTO.getMaterielId());
		}
		
		// Récupérer l'état du matériel (peut être "etat" ou "état" selon la sérialisation)
		Object etatObj = material.get("etat");
		if (etatObj == null) {
			etatObj = material.get("état"); // Fallback pour différentes sérialisations
		}
		
		String materialState = etatObj != null ? etatObj.toString() : null;
		
		if (materialState == null || !"DISPONIBLE".equals(materialState)) {
			throw new RuntimeException("Le matériel n'est pas disponible. État actuel: " + materialState);
		}
		
		// Vérifier qu'il n'y a pas déjà un prêt en cours pour ce matériel
		if (loanRepository.existsByMaterielIdAndStatutIn(
				loanDTO.getMaterielId(),
				List.of(LoanStatus.EN_COURS, LoanStatus.EN_RETARD))) {
			throw new RuntimeException("Ce matériel est déjà en prêt");
		}
		
		// Créer le prêt
		Loan loan = toEntity(loanDTO);
		loan.setDatePret(LocalDate.now());
		loan.setStatut(LoanStatus.EN_COURS);
		loan.setPenalite(0.0);
		
		// Sauvegarder le prêt d'abord
		loan = loanRepository.save(loan);
		
		// Mettre à jour l'état du matériel à EMPRUNTE
		// Note: En cas d'échec, le prêt existe déjà mais le matériel reste DISPONIBLE
		// Dans un système de production, utiliser un pattern Saga pour la compensation
		try {
			materialClient.updateMaterialState(loanDTO.getMaterielId(), "EMPRUNTE");
		} catch (Exception e) {
			log.error("Erreur lors de la mise à jour de l'état du matériel {}: {}", 
					loanDTO.getMaterielId(), e.getMessage());
			// Optionnel: marquer le prêt comme en erreur ou utiliser un mécanisme de retry
			throw new RuntimeException("Erreur lors de la mise à jour de l'état du matériel", e);
		}
		
		return toDTO(loan);
	}
	
	public LoanDTO returnLoan(Long loanId) {
		Loan loan = loanRepository.findById(loanId)
				.orElseThrow(() -> new RuntimeException("Prêt non trouvé avec l'ID: " + loanId));
		
		if (loan.getStatut() == LoanStatus.RETOURNE) {
			throw new RuntimeException("Ce prêt a déjà été retourné");
		}
		
		loan.setDateRetour(LocalDate.now());
		loan.setStatut(LoanStatus.RETOURNE);
		
		// Calculer la pénalité si retour en retard
		if (loan.getDateRetour().isAfter(loan.getDateRetourPrevue())) {
			long joursRetard = java.time.temporal.ChronoUnit.DAYS.between(
					loan.getDateRetourPrevue(), loan.getDateRetour());
			// S'assurer que la pénalité n'est jamais négative
			loan.setPenalite(Math.max(0, joursRetard) * 5.0); // 5€ par jour de retard
		} else {
			loan.setPenalite(0.0); // Pas de pénalité si retour à temps
		}
		
		// Sauvegarder le prêt d'abord
		loan = loanRepository.save(loan);
		
		// Remettre le matériel à DISPONIBLE
		try {
			materialClient.updateMaterialState(loan.getMaterielId(), "DISPONIBLE");
		} catch (Exception e) {
			log.error("Erreur lors de la mise à jour de l'état du matériel {}: {}", 
					loan.getMaterielId(), e.getMessage());
			// Le prêt est déjà marqué comme retourné, mais le matériel reste EMPRUNTE
			// Dans un système de production, utiliser un mécanisme de retry
			throw new RuntimeException("Erreur lors de la mise à jour de l'état du matériel", e);
		}
		
		return toDTO(loan);
	}
	
	// Vérifier et mettre à jour les prêts en retard
	public void checkAndUpdateOverdueLoans() {
		LocalDate today = LocalDate.now();
		List<Loan> overdueLoans = loanRepository.findByDateRetourPrevueBeforeAndStatut(
				today, LoanStatus.EN_COURS);
		
		for (Loan loan : overdueLoans) {
			loan.setStatut(LoanStatus.EN_RETARD);
			loanRepository.save(loan);
			log.info("Prêt {} marqué comme en retard", loan.getId());
		}
	}
	
	@Transactional(readOnly = true)
	public List<LoanDTO> getAllLoans() {
		return loanRepository.findAll().stream()
				.map(this::toDTO)
				.collect(Collectors.toList());
	}
	
	@Transactional(readOnly = true)
	public LoanDTO getLoanById(Long id) {
		Loan loan = loanRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Prêt non trouvé avec l'ID: " + id));
		return toDTO(loan);
	}
	
	// Historique par emprunteur
	@Transactional(readOnly = true)
	public List<LoanDTO> getLoansByBorrower(Long emprunteurId) {
		return loanRepository.findByEmprunteurId(emprunteurId).stream()
				.map(this::toDTO)
				.collect(Collectors.toList());
	}
	
	// Historique par matériel
	@Transactional(readOnly = true)
	public List<LoanDTO> getLoansByMaterial(Long materielId) {
		return loanRepository.findByMaterielId(materielId).stream()
				.map(this::toDTO)
				.collect(Collectors.toList());
	}
	
	@Transactional(readOnly = true)
	public List<LoanDTO> getLoansByStatus(LoanStatus status) {
		return loanRepository.findByStatut(status).stream()
				.map(this::toDTO)
				.collect(Collectors.toList());
	}
	
	@Transactional(readOnly = true)
	public List<LoanDTO> getOverdueLoans() {
		return getLoansByStatus(LoanStatus.EN_RETARD);
	}
	
	private LoanDTO toDTO(Loan loan) {
		return new LoanDTO(
				loan.getId(),
				loan.getEmprunteurId(),
				loan.getMaterielId(),
				loan.getDatePret(),
				loan.getDateRetourPrevue(),
				loan.getDateRetour(),
				loan.getStatut(),
				loan.getPenalite()
		);
	}
	
	private Loan toEntity(LoanDTO dto) {
		Loan loan = new Loan();
		loan.setEmprunteurId(dto.getEmprunteurId());
		loan.setMaterielId(dto.getMaterielId());
		loan.setDateRetourPrevue(dto.getDateRetourPrevue());
		return loan;
	}
}

