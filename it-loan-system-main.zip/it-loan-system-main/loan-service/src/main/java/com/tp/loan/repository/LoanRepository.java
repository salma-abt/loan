package com.tp.loan.repository;

import com.tp.loan.model.Loan;
import com.tp.loan.model.Loan.LoanStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface LoanRepository extends JpaRepository<Loan, Long> {
	
	List<Loan> findByEmprunteurId(Long emprunteurId);
	
	List<Loan> findByMaterielId(Long materielId);
	
	List<Loan> findByStatut(LoanStatus statut);
	
	List<Loan> findByDateRetourPrevueBeforeAndStatut(LocalDate date, LoanStatus statut);
	
	boolean existsByMaterielIdAndStatutIn(Long materielId, List<LoanStatus> statuts);
}

