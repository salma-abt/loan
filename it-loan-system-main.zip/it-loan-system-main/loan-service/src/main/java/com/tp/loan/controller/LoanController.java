package com.tp.loan.controller;

import com.tp.loan.dto.LoanDTO;
import com.tp.loan.model.Loan.LoanStatus;
import com.tp.loan.service.LoanService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/loans")
@RequiredArgsConstructor
public class LoanController {
	
	private final LoanService loanService;
	
	@GetMapping
	public ResponseEntity<List<LoanDTO>> getAllLoans() {
		return ResponseEntity.ok(loanService.getAllLoans());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<LoanDTO> getLoanById(@PathVariable Long id) {
		return ResponseEntity.ok(loanService.getLoanById(id));
	}
	
	@GetMapping("/borrower/{borrowerId}")
	public ResponseEntity<List<LoanDTO>> getLoansByBorrower(@PathVariable Long borrowerId) {
		return ResponseEntity.ok(loanService.getLoansByBorrower(borrowerId));
	}
	
	@GetMapping("/material/{materialId}")
	public ResponseEntity<List<LoanDTO>> getLoansByMaterial(@PathVariable Long materialId) {
		return ResponseEntity.ok(loanService.getLoansByMaterial(materialId));
	}
	
	@GetMapping("/status/{status}")
	public ResponseEntity<List<LoanDTO>> getLoansByStatus(@PathVariable LoanStatus status) {
		return ResponseEntity.ok(loanService.getLoansByStatus(status));
	}
	
	@GetMapping("/overdue")
	public ResponseEntity<List<LoanDTO>> getOverdueLoans() {
		return ResponseEntity.ok(loanService.getOverdueLoans());
	}
	
	@PostMapping
	public ResponseEntity<LoanDTO> createLoan(@Valid @RequestBody LoanDTO loanDTO) {
		return ResponseEntity.status(HttpStatus.CREATED)
				.body(loanService.createLoan(loanDTO));
	}
	
	@PostMapping("/{id}/return")
	public ResponseEntity<LoanDTO> returnLoan(@PathVariable Long id) {
		return ResponseEntity.ok(loanService.returnLoan(id));
	}
	
	@PostMapping("/check-overdue")
	public ResponseEntity<Void> checkOverdueLoans() {
		loanService.checkAndUpdateOverdueLoans();
		return ResponseEntity.ok().build();
	}
}

