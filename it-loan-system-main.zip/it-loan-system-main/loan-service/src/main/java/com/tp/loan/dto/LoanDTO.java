package com.tp.loan.dto;

import com.tp.loan.model.Loan.LoanStatus;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoanDTO {
	private Long id;
	
	@NotNull(message = "L'ID de l'emprunteur est obligatoire")
	private Long emprunteurId;
	
	@NotNull(message = "L'ID du matériel est obligatoire")
	private Long materielId;
	
	private LocalDate datePret;
	
	@NotNull(message = "La date de retour prévue est obligatoire")
	@Future(message = "La date de retour prévue doit être dans le futur")
	private LocalDate dateRetourPrevue;
	
	private LocalDate dateRetour;
	private LoanStatus statut;
	private Double penalite;
}

