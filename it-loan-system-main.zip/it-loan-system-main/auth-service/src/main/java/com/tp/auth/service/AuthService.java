package com.tp.auth.service;

import com.tp.auth.dto.AuthResponse;
import com.tp.auth.dto.LoginRequest;
import com.tp.auth.dto.RegisterRequest;
import com.tp.auth.model.User;
import com.tp.auth.repository.UserRepository;
import com.tp.auth.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class AuthService {
	
	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;
	private final JwtUtil jwtUtil;
	
	public AuthResponse register(RegisterRequest request) {
		if (request == null) {
			throw new RuntimeException("La requête ne peut pas être null");
		}
		if (request.getUsername() == null || request.getUsername().trim().isEmpty()) {
			throw new RuntimeException("Le nom d'utilisateur est obligatoire");
		}
		if (request.getEmail() == null || request.getEmail().trim().isEmpty()) {
			throw new RuntimeException("L'email est obligatoire");
		}
		if (request.getPassword() == null || request.getPassword().trim().isEmpty()) {
			throw new RuntimeException("Le mot de passe est obligatoire");
		}
		if (userRepository.existsByUsername(request.getUsername())) {
			throw new RuntimeException("Le nom d'utilisateur existe déjà");
		}
		
		if (userRepository.existsByEmail(request.getEmail())) {
			throw new RuntimeException("L'email existe déjà");
		}
		
		User user = new User();
		user.setUsername(request.getUsername());
		user.setEmail(request.getEmail());
		user.setPassword(passwordEncoder.encode(request.getPassword()));
		user.setRole(request.getRole() != null ? request.getRole() : User.Role.USER);
		
		user = userRepository.save(user);
		
		String token = jwtUtil.generateToken(user.getUsername(), user.getRole().name());
		
		return new AuthResponse(token, user.getUsername(), user.getEmail(), user.getRole());
	}
	
	public AuthResponse login(LoginRequest request) {
		if (request == null) {
			throw new RuntimeException("La requête ne peut pas être null");
		}
		if (request.getUsername() == null || request.getUsername().trim().isEmpty()) {
			throw new RuntimeException("Le nom d'utilisateur est obligatoire");
		}
		if (request.getPassword() == null || request.getPassword().trim().isEmpty()) {
			throw new RuntimeException("Le mot de passe est obligatoire");
		}
		User user = userRepository.findByUsername(request.getUsername())
				.orElseThrow(() -> new RuntimeException("Nom d'utilisateur ou mot de passe incorrect"));
		
		if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
			throw new RuntimeException("Nom d'utilisateur ou mot de passe incorrect");
		}
		
		String token = jwtUtil.generateToken(user.getUsername(), user.getRole().name());
		
		return new AuthResponse(token, user.getUsername(), user.getEmail(), user.getRole());
	}
	
	@Transactional(readOnly = true)
	public Boolean validateToken(String token) {
		if (token == null || token.trim().isEmpty()) {
			return false;
		}
		try {
			String username = jwtUtil.getUsernameFromToken(token);
			return jwtUtil.validateToken(token, username);
		} catch (Exception e) {
			return false;
		}
	}
	
	@Transactional(readOnly = true)
	public String getRoleFromToken(String token) {
		if (token == null || token.trim().isEmpty()) {
			return null;
		}
		try {
			return jwtUtil.getRoleFromToken(token);
		} catch (Exception e) {
			return null;
		}
	}
}

