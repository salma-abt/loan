package com.tp.auth.dto;

import com.tp.auth.model.User.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegisterRequest {
	@NotBlank(message = "Le nom d'utilisateur est obligatoire")
	private String username;
	
	@NotBlank(message = "L'email est obligatoire")
	@Email(message = "L'email doit être valide")
	private String email;
	
	@NotBlank(message = "Le mot de passe est obligatoire")
	private String password;
	
	private Role role = Role.USER; // Par défaut USER
}

