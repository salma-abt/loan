package com.tp.it_loan_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItLoanSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
