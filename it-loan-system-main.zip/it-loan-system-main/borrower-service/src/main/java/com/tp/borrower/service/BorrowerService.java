package com.tp.borrower.service;

import com.tp.borrower.dto.BorrowerDTO;
import com.tp.borrower.model.Borrower;
import com.tp.borrower.repository.BorrowerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class BorrowerService {
	
	private final BorrowerRepository borrowerRepository;
	
	@Transactional(readOnly = true)
	public List<BorrowerDTO> getAllBorrowers() {
		return borrowerRepository.findAll().stream()
				.map(this::toDTO)
				.collect(Collectors.toList());
	}
	
	@Transactional(readOnly = true)
	public BorrowerDTO getBorrowerById(Long id) {
		Borrower borrower = borrowerRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Emprunteur non trouvé avec l'ID: " + id));
		return toDTO(borrower);
	}
	
	public BorrowerDTO createBorrower(BorrowerDTO borrowerDTO) {
		if (borrowerDTO == null) {
			throw new RuntimeException("L'emprunteur ne peut pas être null");
		}
		if (borrowerDTO.getEmail() == null || borrowerDTO.getEmail().trim().isEmpty()) {
			throw new RuntimeException("L'email est obligatoire");
		}
		if (borrowerRepository.existsByEmail(borrowerDTO.getEmail())) {
			throw new RuntimeException("Un emprunteur avec cet email existe déjà");
		}
		Borrower borrower = toEntity(borrowerDTO);
		borrower = borrowerRepository.save(borrower);
		return toDTO(borrower);
	}
	
	public BorrowerDTO updateBorrower(Long id, BorrowerDTO borrowerDTO) {
		if (borrowerDTO == null) {
			throw new RuntimeException("L'emprunteur ne peut pas être null");
		}
		Borrower borrower = borrowerRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Emprunteur non trouvé avec l'ID: " + id));
		
		if (borrowerDTO.getEmail() != null &&
				!borrower.getEmail().equals(borrowerDTO.getEmail()) &&
				borrowerRepository.existsByEmail(borrowerDTO.getEmail())) {
			throw new RuntimeException("Un emprunteur avec cet email existe déjà");
		}
		
		borrower.setNom(borrowerDTO.getNom());
		borrower.setEmail(borrowerDTO.getEmail());
		borrower.setDepartement(borrowerDTO.getDepartement());
		borrower.setFiliere(borrowerDTO.getFiliere());
		borrower.setTelephone(borrowerDTO.getTelephone());
		
		borrower = borrowerRepository.save(borrower);
		return toDTO(borrower);
	}
	
	public void deleteBorrower(Long id) {
		if (!borrowerRepository.existsById(id)) {
			throw new RuntimeException("Emprunteur non trouvé avec l'ID: " + id);
		}
		borrowerRepository.deleteById(id);
	}
	
	@Transactional(readOnly = true)
	public List<BorrowerDTO> getBorrowersByDepartement(String departement) {
		return borrowerRepository.findByDepartement(departement).stream()
				.map(this::toDTO)
				.collect(Collectors.toList());
	}
	
	@Transactional(readOnly = true)
	public List<BorrowerDTO> getBorrowersByFiliere(String filiere) {
		return borrowerRepository.findByFiliere(filiere).stream()
				.map(this::toDTO)
				.collect(Collectors.toList());
	}
	
	private BorrowerDTO toDTO(Borrower borrower) {
		return new BorrowerDTO(
				borrower.getId(),
				borrower.getNom(),
				borrower.getEmail(),
				borrower.getDepartement(),
				borrower.getFiliere(),
				borrower.getTelephone()
		);
	}
	
	private Borrower toEntity(BorrowerDTO dto) {
		Borrower borrower = new Borrower();
		borrower.setNom(dto.getNom());
		borrower.setEmail(dto.getEmail());
		borrower.setDepartement(dto.getDepartement());
		borrower.setFiliere(dto.getFiliere());
		borrower.setTelephone(dto.getTelephone());
		return borrower;
	}
}

