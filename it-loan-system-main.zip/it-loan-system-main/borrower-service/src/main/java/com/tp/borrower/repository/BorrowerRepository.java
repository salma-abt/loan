package com.tp.borrower.repository;

import com.tp.borrower.model.Borrower;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BorrowerRepository extends JpaRepository<Borrower, Long> {
	
	Optional<Borrower> findByEmail(String email);
	
	List<Borrower> findByDepartement(String departement);
	
	List<Borrower> findByFiliere(String filiere);
	
	boolean existsByEmail(String email);
}

