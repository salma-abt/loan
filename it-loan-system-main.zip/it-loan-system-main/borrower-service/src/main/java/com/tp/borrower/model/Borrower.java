package com.tp.borrower.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "borrowers")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Borrower {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message = "Le nom est obligatoire")
	@Column(nullable = false)
	private String nom;
	
	@NotBlank(message = "L'email est obligatoire")
	@Email(message = "L'email doit être valide")
	@Column(nullable = false, unique = true)
	private String email;
	
	@Column
	private String departement; // Pour les employés
	
	@Column
	private String filiere; // Pour les étudiants
	
	@Column
	private String telephone;
}

