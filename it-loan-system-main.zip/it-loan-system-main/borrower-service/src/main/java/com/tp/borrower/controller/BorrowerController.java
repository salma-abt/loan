package com.tp.borrower.controller;

import com.tp.borrower.dto.BorrowerDTO;
import com.tp.borrower.service.BorrowerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/borrowers")
@RequiredArgsConstructor
public class BorrowerController {
	
	private final BorrowerService borrowerService;
	
	@GetMapping
	public ResponseEntity<List<BorrowerDTO>> getAllBorrowers() {
		return ResponseEntity.ok(borrowerService.getAllBorrowers());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<BorrowerDTO> getBorrowerById(@PathVariable Long id) {
		return ResponseEntity.ok(borrowerService.getBorrowerById(id));
	}
	
	@GetMapping("/departement/{departement}")
	public ResponseEntity<List<BorrowerDTO>> getBorrowersByDepartement(@PathVariable String departement) {
		return ResponseEntity.ok(borrowerService.getBorrowersByDepartement(departement));
	}
	
	@GetMapping("/filiere/{filiere}")
	public ResponseEntity<List<BorrowerDTO>> getBorrowersByFiliere(@PathVariable String filiere) {
		return ResponseEntity.ok(borrowerService.getBorrowersByFiliere(filiere));
	}
	
	@PostMapping
	public ResponseEntity<BorrowerDTO> createBorrower(@Valid @RequestBody BorrowerDTO borrowerDTO) {
		return ResponseEntity.status(HttpStatus.CREATED)
				.body(borrowerService.createBorrower(borrowerDTO));
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<BorrowerDTO> updateBorrower(
			@PathVariable Long id,
			@Valid @RequestBody BorrowerDTO borrowerDTO) {
		return ResponseEntity.ok(borrowerService.updateBorrower(id, borrowerDTO));
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteBorrower(@PathVariable Long id) {
		borrowerService.deleteBorrower(id);
		return ResponseEntity.noContent().build();
	}
}

