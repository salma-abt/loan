package com.tp.borrower.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BorrowerDTO {
	private Long id;
	private String nom;
	private String email;
	private String departement;
	private String filiere;
	private String telephone;
}

