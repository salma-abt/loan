# 📦 Système de Gestion de Prêts de Matériel Informatique (IT Loan System)

[![Java](https://img.shields.io/badge/Java-17-orange.svg)](https://www.oracle.com/java/)
[![Spring Boot](https://img.shields.io/badge/Spring%20Boot-4.0.0-brightgreen.svg)](https://spring.io/projects/spring-boot)
[![Spring Cloud](https://img.shields.io/badge/Spring%20Cloud-2025.1.0-blue.svg)](https://spring.io/projects/spring-cloud)
[![Docker](https://img.shields.io/badge/Docker-Ready-blue.svg)](https://www.docker.com/)

Système de gestion de prêts de matériel informatique basé sur une architecture microservices avec Spring Boot et Spring Cloud. Ce projet permet de gérer le parc informatique, les emprunteurs (employés/étudiants), les prêts, les retours et les pénalités.

## 📋 Table des Matières

- [Architecture](#architecture)
- [Technologies](#technologies-utilisées)
- [Structure du Projet](#structure-du-projet)
- [Fonctionnalités](#fonctionnalités)
- [Prérequis](#prérequis)
- [Installation et Démarrage](#installation-et-démarrage)
- [API Endpoints](#api-endpoints)
- [Exemples d'Utilisation](#exemples-dutilisation)
- [Docker](#docker)
- [Contribution](#contribution)

## 🏗️ Architecture

Le système est composé de **6 microservices** :

| Service | Port | Description |
|---------|------|-------------|
| **Eureka Server** | 8761 | Service de découverte et enregistrement |
| **Material Service** | 8081 | Gestion du parc informatique |
| **Borrower Service** | 8082 | Gestion des emprunteurs (Employés/Étudiants) |
| **Loan Service** | 8083 | Gestion des prêts, retours et pénalités |
| **Auth Service** | 8084 | Authentification avec JWT |
| **API Gateway** | 8080 | Point d'entrée unique pour tous les services |

### Diagramme d'Architecture

```
┌─────────────┐
│   Client    │
└──────┬──────┘
       │
       ▼
┌─────────────────┐
│   API Gateway    │ (Port 8080)
└────────┬─────────┘
         │
    ┌────┴────┬──────────┬──────────┬──────────┐
    │         │          │          │          │
    ▼         ▼          ▼          ▼          ▼
┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌──────────┐
│Material│ │Borrower│ │  Loan  │ │  Auth  │ │  Eureka  │
│Service │ │Service │ │Service │ │Service │ │  Server  │
│ :8081  │ │ :8082  │ │ :8083  │ │ :8084  │ │  :8761   │
└────────┘ └────────┘ └────────┘ └────────┘ └──────────┘
```

## 🛠️ Technologies Utilisées

- **Spring Boot 4.0.0** - Framework Java
- **Spring Cloud 2025.1.0** - Outils cloud
- **Spring Cloud Netflix Eureka** - Service Discovery
- **Spring Cloud Gateway** - API Gateway
- **Spring Data JPA** - Persistance des données
- **H2 Database** - Base de données en mémoire (développement)
- **JWT (JSON Web Tokens)** - Authentification sécurisée
- **Lombok** - Réduction du code boilerplate
- **Docker & Docker Compose** - Conteneurisation
- **Maven** - Gestion des dépendances

## 📁 Structure du Projet

```
it-loan-system/
├── src/                          # Eureka Server (projet racine)
│   ├── main/java/.../ItLoanSystemApplication.java
│   └── resources/application.properties
├── material-service/             # Service des matériels
│   ├── src/main/java/com/tp/material/
│   │   ├── model/Material.java
│   │   ├── repository/MaterialRepository.java
│   │   ├── service/MaterialService.java
│   │   └── controller/MaterialController.java
│   └── pom.xml
├── borrower-service/             # Service des emprunteurs
│   ├── src/main/java/com/tp/borrower/
│   └── pom.xml
├── loan-service/                 # Service des prêts
│   ├── src/main/java/com/tp/loan/
│   │   ├── client/               # Feign Clients
│   │   ├── model/Loan.java
│   │   ├── service/LoanService.java
│   │   └── controller/LoanController.java
│   └── pom.xml
├── auth-service/                 # Service d'authentification
│   ├── src/main/java/com/tp/auth/
│   └── pom.xml
├── api-gateway/                  # Passerelle API
│   ├── src/main/java/com/tp/gateway/
│   └── pom.xml
├── docker-compose.yml            # Orchestration Docker
├── build-all.sh                  # Script de build (Linux/Mac)
├── build-all.bat                 # Script de build (Windows)
└── README.md
```

## ✨ Fonctionnalités

### Entités Principales

#### 📦 Matériel
- Gestion du parc informatique (PC, projecteurs, imprimantes, etc.)
- États : `DISPONIBLE`, `EMPRUNTE`, `EN_PANNE`, `EN_MAINTENANCE`
- Suivi par numéro de série unique
- Localisation

#### 👤 Emprunteur
- Gestion des employés et étudiants
- Support département/filière
- Informations de contact

#### 📝 Prêt
- Création et gestion des prêts
- Suivi des dates (prêt, retour prévu, retour effectif)
- Statuts : `EN_COURS`, `RETOURNE`, `EN_RETARD`
- Calcul automatique des pénalités (5€/jour de retard)

### Règles Métier

1. ✅ **Disponibilité** : Un matériel ne peut être prêté que s'il est `DISPONIBLE`
2. ✅ **Retard** : Détection automatique si `dateRetour > dateRetourPrevue`
3. ✅ **Pénalité** : Calcul automatique (5€ par jour de retard)
4. ✅ **Historique** : Consultation par emprunteur et par matériel
5. ✅ **Authentification** : JWT avec rôles (ADMIN/USER)

## 📦 Prérequis

### Pour le développement local :
- ☕ **Java 17** ou supérieur
- 📦 **Maven 3.6+**
- 🐳 **Docker** et **Docker Compose** (optionnel, pour la conteneurisation)

### Pour Docker uniquement :
- 🐳 **Docker Desktop** ou **Docker Engine** + **Docker Compose**

## 🚀 Installation et Démarrage

### Option 1 : Démarrage avec Docker (Recommandé)

#### Étape 1 : Cloner le projet
```bash
git clone https://github.com/VOTRE-USERNAME/it-loan-system.git
cd it-loan-system
```

#### Étape 2 : Construire tous les services

**Sur Windows :**
```bash
build-all.bat
```

**Sur Linux/Mac :**
```bash
chmod +x build-all.sh
./build-all.sh
```

**Ou manuellement :**
```bash
# Eureka Server
mvn clean package -DskipTests

# Material Service
cd material-service && mvn clean package -DskipTests && cd ..

# Borrower Service
cd borrower-service && mvn clean package -DskipTests && cd ..

# Loan Service
cd loan-service && mvn clean package -DskipTests && cd ..

# Auth Service
cd auth-service && mvn clean package -DskipTests && cd ..

# API Gateway
cd api-gateway && mvn clean package -DskipTests && cd ..
```

#### Étape 3 : Démarrer avec Docker Compose
```bash
docker-compose up --build
```

#### Étape 4 : Accéder aux services
- 🌐 **Eureka Dashboard** : http://localhost:8761
- 🚪 **API Gateway** : http://localhost:8080
- 📦 **Material Service** : http://localhost:8081
- 👤 **Borrower Service** : http://localhost:8082
- 📝 **Loan Service** : http://localhost:8083
- 🔐 **Auth Service** : http://localhost:8084

### Option 2 : Démarrage Local (sans Docker)

#### Étape 1 : Démarrer Eureka Server
```bash
mvn spring-boot:run
```

#### Étape 2 : Démarrer les autres services (dans des terminaux séparés)

**Terminal 2 - Material Service :**
```bash
cd material-service
mvn spring-boot:run
```

**Terminal 3 - Borrower Service :**
```bash
cd borrower-service
mvn spring-boot:run
```

**Terminal 4 - Loan Service :**
```bash
cd loan-service
mvn spring-boot:run
```

**Terminal 5 - Auth Service :**
```bash
cd auth-service
mvn spring-boot:run
```

**Terminal 6 - API Gateway :**
```bash
cd api-gateway
mvn spring-boot:run
```

## 📡 API Endpoints

Tous les endpoints sont accessibles via l'**API Gateway** (Port 8080).

### 🔐 Authentification

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/api/auth/register` | Inscription d'un nouvel utilisateur |
| POST | `/api/auth/login` | Connexion et obtention du token JWT |
| POST | `/api/auth/validate` | Validation d'un token JWT |

### 📦 Matériels

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/materials` | Liste tous les matériels |
| GET | `/api/materials/{id}` | Obtenir un matériel par ID |
| GET | `/api/materials/available` | Liste les matériels disponibles |
| GET | `/api/materials/state/{state}` | Liste les matériels par état |
| POST | `/api/materials` | Créer un nouveau matériel |
| PUT | `/api/materials/{id}` | Mettre à jour un matériel |
| PATCH | `/api/materials/{id}/state?state=EMPRUNTE` | Mettre à jour l'état d'un matériel |
| DELETE | `/api/materials/{id}` | Supprimer un matériel |

### 👤 Emprunteurs

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/borrowers` | Liste tous les emprunteurs |
| GET | `/api/borrowers/{id}` | Obtenir un emprunteur par ID |
| GET | `/api/borrowers/departement/{departement}` | Liste par département |
| GET | `/api/borrowers/filiere/{filiere}` | Liste par filière |
| POST | `/api/borrowers` | Créer un nouvel emprunteur |
| PUT | `/api/borrowers/{id}` | Mettre à jour un emprunteur |
| DELETE | `/api/borrowers/{id}` | Supprimer un emprunteur |

### 📝 Prêts

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/api/loans` | Liste tous les prêts |
| GET | `/api/loans/{id}` | Obtenir un prêt par ID |
| GET | `/api/loans/borrower/{borrowerId}` | Historique par emprunteur |
| GET | `/api/loans/material/{materialId}` | Historique par matériel |
| GET | `/api/loans/status/{status}` | Liste par statut |
| GET | `/api/loans/overdue` | Liste les prêts en retard |
| POST | `/api/loans` | Créer un nouveau prêt |
| POST | `/api/loans/{id}/return` | Retourner un prêt |
| POST | `/api/loans/check-overdue` | Vérifier et mettre à jour les retards |

## 💡 Exemples d'Utilisation

### 1. Créer un utilisateur ADMIN

```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "email": "admin@example.com",
    "password": "password123",
    "role": "ADMIN"
  }'
```

**Réponse :**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "username": "admin",
  "email": "admin@example.com",
  "role": "ADMIN"
}
```

### 2. Se connecter

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "password123"
  }'
```

### 3. Créer un matériel

```bash
curl -X POST http://localhost:8080/api/materials \
  -H "Content-Type: application/json" \
  -d '{
    "type": "PC",
    "marque": "Dell",
    "modele": "Latitude 5520",
    "numeroSerie": "SN123456",
    "etat": "DISPONIBLE",
    "localisation": "Salle 101"
  }'
```

### 4. Créer un emprunteur

```bash
curl -X POST http://localhost:8080/api/borrowers \
  -H "Content-Type: application/json" \
  -d '{
    "nom": "Jean Dupont",
    "email": "jean.dupont@example.com",
    "departement": "Informatique",
    "telephone": "0123456789"
  }'
```

### 5. Créer un prêt

```bash
curl -X POST http://localhost:8080/api/loans \
  -H "Content-Type: application/json" \
  -d '{
    "emprunteurId": 1,
    "materielId": 1,
    "dateRetourPrevue": "2024-12-31"
  }'
```

### 6. Retourner un prêt

```bash
curl -X POST http://localhost:8080/api/loans/1/return
```

### 7. Consulter l'historique d'un emprunteur

```bash
curl http://localhost:8080/api/loans/borrower/1
```

### 8. Consulter l'historique d'un matériel

```bash
curl http://localhost:8080/api/loans/material/1
```

## 🐳 Docker

### Commandes Docker utiles

```bash
# Démarrer tous les services
docker-compose up --build

# Démarrer en arrière-plan
docker-compose up -d

# Arrêter tous les services
docker-compose down

# Voir les logs
docker-compose logs -f

# Reconstruire un service spécifique
docker-compose up --build material-service
```

### Structure Docker

Chaque service a son propre `Dockerfile` et tous sont orchestrés via `docker-compose.yml`. Les services communiquent via un réseau Docker dédié.

## 🔒 Sécurité

- **JWT** : Authentification basée sur les tokens
- **Rôles** : ADMIN et USER
- **Validation** : Validation des entrées avec Jakarta Validation
- **CORS** : Configuration CORS dans l'API Gateway

## 📝 Notes Importantes

- ⚠️ Les bases de données **H2** sont en mémoire et seront perdues au redémarrage
- 🔄 Pour la production, remplacer H2 par **PostgreSQL** ou **MySQL**
- 🔐 Configurer les secrets JWT de manière sécurisée en production
- 🧪 Ajouter des tests unitaires et d'intégration
- 📚 Implémenter la documentation Swagger/OpenAPI
- 🛡️ Ajouter un gestionnaire d'erreurs global avec `@ControllerAdvice`

## 🤝 Contribution

Les contributions sont les bienvenues ! Pour contribuer :

1. Fork le projet
2. Créer une branche pour votre fonctionnalité (`git checkout -b feature/AmazingFeature`)
3. Commit vos changements (`git commit -m 'Add some AmazingFeature'`)
4. Push vers la branche (`git push origin feature/AmazingFeature`)
5. Ouvrir une Pull Request

## 📄 Licence

Ce projet est développé dans le cadre d'un cours de microservices.

## 👤 Auteur

Développé dans le cadre d'un projet académique sur les microservices.

---

⭐ Si ce projet vous a aidé, n'hésitez pas à lui donner une étoile !
